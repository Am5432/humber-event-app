"""Admin application services."""
