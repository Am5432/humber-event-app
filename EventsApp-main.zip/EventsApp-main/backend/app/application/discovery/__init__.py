"""Discovery application services."""
